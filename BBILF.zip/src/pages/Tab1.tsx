import { IonContent, IonButton, IonIcon, IonPage, IonTitle} from '@ionic/react';
import ExploreContainer from '../components/ExploreContainer';
import {chatbubbleEllipses} from 'ionicons/icons'
import './Tab1.css';
import logo from "../PicData/Product-_1_.svg" 
import React, {useEffect} from 'react'
import ReactDOM from 'react-dom/client'
import {withRouter} from 'react-router';
import { Redirect, Route, NavLink } from "react-router-dom";

const Tab1: React.FC = () => {
	useEffect(() => {
    	setTimeout(getUserHome,15);
  	});
  return (
	<IonPage >
	{global.userID == undefined ? <Redirect to="/login" /> : null}
	  <IonContent fullscreen>
		<div className='logo' id = "logo"><IonIcon className="CustomIonicIconSize" src={logo} /></div>
		<br></br>
		<br></br>
		<br></br>
		<br></br>
		<br></br>
		<br></br>
		<div className='paddedPage' id="page">
		</div>
	  </IonContent>
	</IonPage>
  );
};

global.addEventListener('loggedIn', () => {},false);
global.addEventListener('loggedIn', showBar,false);
async function getUserHome()
{
	if("" + global.userID !== "undefined")
	{
		var url : string = "http://192.168.68.107/GetUserHome" + global.userID + "," + global.sessionID;
		console.log(url);
		var res = "meow";
  		fetch(url).then(
			function(response:any)
			{
	  			response.text().then(
					function(responseString: any)
					{ 
		  				console.log(responseString);
		  				var usersData = responseString.split("|||");
		  				var usrs = [];
		  				console.log(usersData);
		  				for(var i = 0; i < usersData.length -1; i++)
		  				{
							console.log("going over user");
							var usrString = usersData[i];
							var USR = usrString.split(",");
							console.log(USR);
							usrs.push(React.createElement(User, {name:USR[0].toLowerCase(),ranking:USR[1],pfpURL:USR[2]},null));
		  				}
		  				var page = document.getElementById("page");
		  				if(page != null)
		  				{
							console.log("rendering users");
							var root = ReactDOM.createRoot(page);
							root.render(usrs);
		  				}
					}
				);
  			}
  		);
	}
}


export default Tab1;
function showBar()
{
  const tabBar = document.getElementById('appTabBar');
  if (tabBar !== null) {
	  tabBar.style.display = 'flex';
  }
  console.log(tabBar);  
}



function User(data:{name:string,ranking:string,pfpURL:string})
{
  var Name = "";
  var Rank = +data.ranking;
  if(data.name.length > 10)
  {
	Name = data.name.slice(0, 10).concat('...');
	Name = Name.toLowerCase();
  }
  else
  {
	Name = data.name.toLowerCase();
  }
  return <IonButton className="UserButton" color='none' onClick={(event) => {OnUserClicked(data.name); }}>
	<div className = "user">
	  
	  <p className="Username">{Name.toLowerCase()}</p>
	  <img className="circle" src={data.pfpURL} width= {70} height={70}></img>
	  <div className="star">
		  <p>{Rank}</p>
		  <img src="https://icons.iconarchive.com/icons/google/noto-emoji-travel-places/256/42655-star-icon.png" width= {30} height= {30}></img>
	  </div>
	</div>
  </IonButton>
}

function OnMessageButtonClicked(data:string)
{
  alert("messaging...");
}

function OnUserClicked(data:string)
{
  alert("clicked on "+ data);
}
