import { IonContent,IonButton, IonIcon, IonPage, IonTitle, IonFabButton, IonFab} from '@ionic/react';
import './Tab3.css';
import { Redirect, Route, NavLink } from "react-router-dom";
import {chatbubbleEllipses} from 'ionicons/icons'
import logo from "../PicData/Product-_1_.svg" 
import React, {useEffect} from 'react'
import ReactDOM from 'react-dom/client'
import {withRouter} from 'react-router';
const Tab3: React.FC = () => {
  return (
	<IonPage>
	{global.userID == undefined ? <Redirect to="/login" /> : null}
	  <IonContent fullscreen>
		<UserProfile name="medina" pfpURL="https://www.law.berkeley.edu/wp-content/uploads/2015/04/Blank-profile.png"/>
	  </IonContent>
	</IonPage>
  );
};

function UserProfile(data:{name:string,pfpURL:string})
{
	var Name = "";
	if(data.name.length > 10)
	{
		Name = data.name.slice(0, 10).concat('...');
		Name = Name.toLowerCase();
	}
	else
	{
		Name = data.name.toLowerCase();
	}
	return (
	<div>
		<p>{Name}</p>
	</div>
	);
}
export default Tab3;
